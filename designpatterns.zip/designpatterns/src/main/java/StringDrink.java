public class StringDrink {


    private String text;

    StringDrink(String t){
        this.text=t;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
