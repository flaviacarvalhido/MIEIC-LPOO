public class StringBar extends Bar {

    private boolean happy=false;

    StringBar(){};

    public boolean isHappyHour() {
        return happy;
    }
    public void startHappyHour() {
        this.happy=true;
    }
    public void endHappyHour() {
        this.happy=false;
    }
}
